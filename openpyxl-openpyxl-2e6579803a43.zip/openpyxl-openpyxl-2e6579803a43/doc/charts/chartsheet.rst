Chartsheets
===========

Chartsheets are special worksheets which only contain charts. All the data
for the chart must be on a different worksheet.

.. literalinclude:: chartsheet.py


.. image:: chartsheet.png
   :alt: "Sample chartsheet"
