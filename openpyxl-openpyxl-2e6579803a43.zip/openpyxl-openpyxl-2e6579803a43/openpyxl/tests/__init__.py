from __future__ import absolute_import
# Copyright (c) 2010-2018 openpyxl

import os

KEEP_VBA = os.environ.get("OPENPYXL_KEEP_VBA", "False") == "True"
